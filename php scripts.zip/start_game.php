<?php

include_once("connect.php");
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["name"]);
$token = preg_replace("/[^a-z0-9]/","",$_POST["token"]);

$querycheck = mysql_query("SELECT id FROM users WHERE naam='".$name."' AND token='".$token."'");

$check = mysql_num_rows($querycheck);

if($check == 1)
{
while($r = mysql_fetch_assoc($querycheck))
{
$id = $r['id'];
}
$query = mysql_query("SELECT deelnemers,aantal FROM current_games WHERE deelnemers LIKE '".$id.",%'");
if(mysql_num_rows($query)==1)
{
$update = mysql_query("UPDATE current_games SET status='2' WHERE deelnemers LIKE '".$id.",%'");
if($update)
{
echo "Ja";
}
else
{
echo "Error: Database fout!";
}
}
else
{
echo "Error: Je bent niet de baas van het spel of je bent de enige in het potje!";
}
}
else
{
echo "Error: Authenticatie ging fout!";
}

?>