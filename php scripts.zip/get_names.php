<?php
include_once("connect.php");
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["name"]);
$token = preg_replace("/[^a-z0-9]/","",$_POST["token"]);

$querycheck = mysql_query("SELECT id FROM users WHERE naam='".$name."' AND token='".$token."'");

$check = mysql_num_rows($querycheck);

if($check == 1)
{
$gameid = preg_replace("/[^0-9]/","",$_POST["gameid"]);

$query = mysql_query("SELECT deelnemers FROM current_games WHERE id='".$gameid."'");

if(mysql_num_rows($query)>0)
{

while($r = mysql_fetch_assoc($query))
{

$ids = explode(",",$r['deelnemers']);
$deelnemersnamen = "";
$i = 0;
foreach($ids as $id)
{
$querynamen = mysql_query("SELECT naam,ranking FROM users WHERE id='".$id."'");
while($row = mysql_fetch_assoc($querynamen))
{
if($i == 0)
{
$deelnemersnamen = $row['naam'].":".$row['ranking'];
$i = 1;
}
else
{
$deelnemersnamen .= ",".$row['naam'].":".$row['ranking'];
}
}
}
}

echo $deelnemersnamen;

}
else
{
echo "Error: De game bestaat niet!";
}
}
else
{
echo "Error: De user check ging fout.";
}

?>