<?php
///////////////////////////////////////////last_action.php//////////////////////////////////////////////

include_once("connect.php");
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["name"]);
$token = preg_replace("/[^a-z0-9]/","",$_POST["token"]);
$gameid = preg_replace("/[^0-9]/","",$_POST["gameid"]);

$querycheck = mysql_query("SELECT id FROM users WHERE naam='".$name."' AND token='".$token."'");

$check = mysql_num_rows($querycheck);

if($check == 1)
{
while($r = mysql_fetch_assoc($querycheck))
{
$id = $r['id'];
}
$update = mysql_query("UPDATE users SET laatste_actie=NOW() WHERE id='".$id."'");
if($update)
{
echo "ja";
}
else
{
echo "Error: Database error!";
}
}
else
{
echo "Error: user bestaat niet!";
}

?>