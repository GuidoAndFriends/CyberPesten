<?php
include_once("connect.php");
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["name"]);
$token = preg_replace("/[^a-z0-9]/","",$_POST["token"]);

$querycheck = mysql_query("SELECT id FROM users WHERE naam='".$name."' AND token='".$token."'");

$check = mysql_num_rows($querycheck);

if($check == 1)
{
while($r = mysql_fetch_assoc($querycheck))
{
$id = $r['id'];
}
$spelid = preg_replace("/[^0-9]/","",$_POST["spelid"]);

if($spelid&&$id)
{
$delete = mysql_query("DELETE FROM current_games WHERE (deelnemers LIKE '".$id.",%' OR deelnemers='".$id."') AND id='".$spelid."'") or die(mysql_error());
if($delete)
{
echo "ja";
}
else
{
echo "Error: Database Error!";
}
}
else
{
echo "Error: Data niet compleet!";
}

}
else
{
echo "Error: De user check ging fout.";
}

?>