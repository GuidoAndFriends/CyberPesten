<?php
/////////////////////////////////////////delete_messages.php///////////////////////////////////////////

include_once("connect.php");
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["name"]);
$token = preg_replace("/[^a-z0-9]/","",$_POST["token"]);

$querycheck = mysql_query("SELECT id FROM users WHERE naam='".$name."' AND token='".$token."'");

$check = mysql_num_rows($querycheck);

if($check == 1)
{
$gameid = preg_replace("/[^0-9]/","",$_POST["gameid"]);

if($name&&$gameid)
{
$sql = "DELETE FROM messages WHERE gameid='".$gameid."'";
$delete = mysql_query($sql);
if($delete)
{
echo "ja";
}
else
{
echo "Error: Database Error!";
}
}
else
{
echo "Error: Data niet compleet!";
}

}
else
{
echo "Error: De user check ging fout.";
}

?>