<?php
include_once("connect.php");
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["name"]);
$token = preg_replace("/[^a-z0-9]/","",$_POST["token"]);

$querycheck = mysql_query("SELECT id FROM users WHERE naam='".$name."' AND token='".$token."'");

$check = mysql_num_rows($querycheck);

if($check == 1)
{


$queryz = mysql_query("SELECT deelnemers,id FROM current_games");
while($r = mysql_fetch_assoc($queryz))
{
$gameid = $r['id'];
$status = $r['status'];
$deelnemers = explode(",",$r['deelnemers']);
for($q = 0;$q<count($deelnemers);$q++)
{
$queryx = mysql_query("SELECT id FROM users WHERE id='".$ids."' AND laatste_actie!=NULL AND TIMESTAMPDIFF(SECOND, laatste_actie, NOW())>60");
while($row = mysql_fetch_assoc($queryx))
{
$z = $row['id'];

$delete = mysql_query("DELETE FROM current_games WHERE id='".$gameid."'") or die(mysql_error());
if($status == 2)
{
$loser = mysql_query("UPDATE users SET ranking=ranking-25 WHERE id='".$z."'") or die(mysql_error());
}
}
}
}



$query = mysql_query("SELECT * FROM current_games");

echo "{";
while($r = mysql_fetch_assoc($query))
{

$ids = explode(",",$r['deelnemers']);
$deelnemersnamen = "";
$i = 0;
foreach($ids as $id)
{
$querynamen = mysql_query("SELECT naam,ranking FROM users WHERE id='".$id."';");
while($row = mysql_fetch_assoc($querynamen))
{
if($i == 0)
{
$deelnemersnamen = $row['naam'].":".$row['ranking'];
$i = 1;
}
else
{
$deelnemersnamen .= ",".$row['naam'].":".$row['ranking'];
}
}
}

echo "{".$r['id']."|".$r['aantal']."|".$deelnemersnamen."|".$r['status']."|".$r['metadata']."|".$r['naam']	."}";
}
echo "}";

}
else
{
echo "Error: De user check ging fout.";
}

?>