<?php
include_once("connect.php");

//variabelen voor de userdatabase defienieren
$uniqueid = $_POST["unid"];
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["name"]);

//check de naam
if(preg_replace("/[ ]/","",$_POST["name"])=="")
{
echo "Error: Geen geldige naam!";
}
else //geldige naam
{

//check of de token klopt
if($uniqueid != "")
{
	//query om de user token combinatie te zoeken
	$query = mysql_query("SELECT * FROM users WHERE `naam`='".$name."' AND `token`='".$uniqueid."'");
	
	if(mysql_num_rows($query)!=0)//de user is goed
	{
	echo "ja";
	}
	else//user bestaat niet
	{
	echo "Error: Er is iets fout gegaan bij de database!";
	}
}
else //token klopt niet
{
echo"Error: De gegevens kloppen niet!";
}

}

mysql_close($con);

?>