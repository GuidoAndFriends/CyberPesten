<?php
include_once("connect.php");
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["name"]);
$token = preg_replace("/[^a-z0-9]/","",$_POST["token"]);

$querycheck = mysql_query("SELECT id FROM users WHERE naam='".$name."' AND token='".$token."'");

$check = mysql_num_rows($querycheck);

if($check == 1)
{
while($r = mysql_fetch_assoc($querycheck))
{
$id = $r['id'];
}
$seed = mysql_real_escape_string($_POST["seed"]);
$naam = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["naam"]);
$aantal = preg_replace("/[^0-9]/","",$_POST["aantal"]);
$deelnemers = $id;
$status = 1;
$metadata = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["metadata"]);

if($seed&&$aantal&&$deelnemers&&$status&&$metadata)
{
$insert = mysql_query("INSERT INTO current_games (id, naam, seed, aantal, deelnemers, status, metadata, laatste_actie, actie_tijd) VALUES (NULL, '".$naam."','".$seed."','".$aantal."','".$deelnemers."','".$status."','".$metadata."','','')");
if($insert)
{
$querycheck = mysql_query("SELECT id FROM current_games WHERE deelnemers = '".$id."'");
$r = mysql_fetch_assoc($querycheck);
echo $r['id'];
}
else
{
echo "Error: Database Error!";
}
}
else
{
echo "Error: Data niet compleet!";
}

}
else
{
echo "Error: De user check ging fout.";
}

?>