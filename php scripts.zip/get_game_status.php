<?php
////////////////////////////////// get_game_status///////////////////////////////////
include_once("connect.php");
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["name"]);
$token = preg_replace("/[^a-z0-9]/","",$_POST["token"]);

$querycheck = mysql_query("SELECT id FROM users WHERE naam='".$name."' AND token='".$token."'");

$check = mysql_num_rows($querycheck);

if($check == 1)
{
$gameid = preg_replace("/[^0-9]/","",$_POST["gameid"]);
if($name&&$gameid)
{

$sql = "SELECT status FROM current_games WHERE id='".$gameid."'";
$query = mysql_query($sql);
if(mysql_num_rows($query)==1)
{
while($r = mysql_fetch_assoc($query))
{
echo $r['status'];
}
}
else
{
echo "Error: Game bestaat niet";
}

}
else
{
echo "Error: Data niet compleet!";
}

}
else
{
echo "Error: De user check ging fout.";
}

?>