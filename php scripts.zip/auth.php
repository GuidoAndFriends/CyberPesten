<?php
include_once("connect.php");
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["name"]);
$name = preg_replace("/[^a-z0-9]/","",$_POST["token"]);

$querycheck = mysql_query("SELECT * FROM users WHERE naam='".$name."' AND token='".$token."'");

$check = mysql_num_rows($querycheck);

?>