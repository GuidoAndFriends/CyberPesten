<?php
/////////////////////////////////////////end_game.php///////////////////////////////////////////

include_once("connect.php");
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["name"]);
$token = preg_replace("/[^a-z0-9]/","",$_POST["token"]);

$querycheck = mysql_query("SELECT id FROM users WHERE naam='".$name."' AND token='".$token."'");

$check = mysql_num_rows($querycheck);

if($check == 1)
{
$winnaar = preg_replace("/[^0-9]/","",$_POST["winnaar"]);
while($r = mysql_fetch_assoc($querycheck))
{
$id = $r['id'];
}
$query = mysql_query("SELECT deelnemers,aantal FROM current_games WHERE deelnemers LIKE '".$id.",%' OR deelnemers='".$id."'");
if(mysql_num_rows($query)==1)
{
while($r = mysql_fetch_assoc($query))
{
$deelnemers = explode(",",$r["deelnemers"]);
}
$pluswinner = count($deelnemers)*2;
if(($key = array_search($winnaar, $deelnemers)) !== false) {
    unset($deelnemers[$key]);
}

$updatewinnaar = mysql_queyr("UPDATE users SET ranking=ranking+".$pluswinner.",games=games+1,wins=wins+1");

foreach($deelnemers as $ids)
{
$update = mysql_query("UPDATE users SET ranking=ranking-1,games=games+1,wins=wins+1");
}

if($update&&$updatewinnaar)
{
echo "Ja";
}
else
{
echo "Error: Database fout!";
}
}
else
{
echo "Error: Je bent niet de baas van het spel!";
}
}
else
{
echo "Error: Authenticatie ging fout!";
}

?>