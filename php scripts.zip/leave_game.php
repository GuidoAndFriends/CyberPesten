<?php
include_once("connect.php");
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_POST["name"]);
$token = preg_replace("/[^a-z0-9]/","",$_POST["token"]);
$spelid = preg_replace("/[^0-9]/","",$_POST["spelid"]);

$querycheck = mysql_query("SELECT id FROM users WHERE naam='".$name."' AND token='".$token."'");

$check = mysql_num_rows($querycheck);

if($check == 1)
{
while($r = mysql_fetch_assoc($querycheck))
{
$id = $r['id'];
}
$query = mysql_query("SELECT deelnemers FROM current_games WHERE id='".$spelid."'");

if(mysql_num_rows($query)>0)
{

if($spelid&&$id)
{
$querycheck = mysql_query("SELECT deelnemers,status FROM current_games WHERE id='".$spelid."'");

$check = mysql_num_rows($querycheck);

if($check == 1)
{
while($r = mysql_fetch_assoc($querycheck))
{
$deelnemers = $r['deelnemers'];
$status = $r['status'];
if($status == 2)
{
$loser = mysql_query("UPDATE users SET ranking=ranking-50 WHERE id='".$id."'") or die(mysql_error());
}
if (strpos($deelnemers, ',') !== FALSE)
{
$deelnemers = explode(",", $deelnemers);
if(($key = array_search($id, $deelnemers)) !== false) {
    unset($deelnemers[$key]);
}
}
else
{
die("Error: Host kan niet leaven, hij kan alleen deleten.");
}
}

$i = 0;
foreach($deelnemers as $elem)
{
if($i==0)
{
$deelnemers1 = $elem;
}
else
{
$deelnemers1 .= ",".$elem;
}
$i++;
}
if($status == 2)
{
$update = mysql_query("DELETE FROM current_games WHERE id='".$spelid."'");
}
else
{
$update = mysql_query("UPDATE current_games SET deelnemers='".$deelnemers1."' WHERE id='".$spelid."'") or die(mysql_error());
}
if($update)
{
echo "ja";
}
else
{
echo "Error: Database Error!";
}
}
else
{
echo "Error: Game bestaat niet!";
}
}
else
{
echo "Error: Data niet compleet!";
}
}
else
{
echo "Error: Game bestaat niet!";
}
}
else
{
echo "Error: De user check ging fout.";
}

?>