<?php
include_once("connect.php");

//variabelen voor de userdatabase defienieren
$uniqueid = $_GET["unid"];
$name = preg_replace("/[^A-Za-z0-9 ]/","",$_GET["name"]);
$datetime = $_GET["datetime"];
$email = mysql_real_escape_string($_GET["email"]);

//check de naam
if(str_replace(" ","",$_GET["name"])=="")
{
echo "Error: Geen geldige naam!";
}
else //geldige naam
{

//check of de gegevens combinatie klopt
if($uniqueid == md5($name."".$datetime))
{
	//voeg user toe met query!
	$query = mysql_query("DELETE FROM users WHERE token='".$uniqueid."' AND naam='".$name."' AND email='".$email."'");
	
	if($query)//geen errors tijdens het toevoegen
	{
	echo "ja";
	}
	else//error bij het toevoegen
	{
	echo "Error: Er is iets fout gegaan bij de database!";
	}
}
else //gegevenscombinatie klopt niet
{
echo"Error: De gegevens kloppen niet!";
}

}

mysql_close($con);

?>